# Bir qatorli izohga olish 

# print(45, '-maktab', 99)
# print("KARAM")

# print("Assalom Foundation",191, sep="-", end="group")
# print("IS THE BEST")

# print(f"{a} + {b} =  {a+b}")

# --------------------------------------------

# Primitive 
    # int float str bool
# Non-primitive 
    # list tuple set dict


# a = 45
# a = "salom"
# a = 45.5
# a = True


# a = int() # 0
# a = float() # 0.0
# a = str() # ''
# a = bool() # False

# a = int("123") # 123
# a = int(123.45) # 123
# a = int("salom") # Error
# a = int("123.85") # Error

# b = float("123") # 123.0
# b = float(12) # 12.0
# b = float("124.20") # 124.2

# c = str(45) # "45"
# c = str(23.6) # "23.6"


# -------------------------------------

# print(type(str(45)))

# -------------------------------------

# a, b = 56, 2
# print(f"{a}+{b}=", c:=a+b, sep="")


# a, b = 90, 45
# a, b = b, a
# print(f"A: {a}\nB: {b}")

# -------------------------------------

# name = input("Ismingizni kiriting: ")
# second = input("Familiyangizni kiriting: ")
# age = int(input("Yoshingizini kiriting: "))
# print(f"""
# FULL NAME: {name} {second}
# Age: {age}""")

# -------------------------------------

#                       MAtematik amallar
# C                              Python
# +                               +
# -                               -
# *                               *
# /                               /   -> kasrli bo'lish
# %                               //  ->  butun bo'lish
#                                 % 
#                                 **


# a, b = 5, 2
# print(a+b) # 7
# print(a-b) # 3
# print(a*b) # 10
# print(a/b) # 2.5
# print(a//b) # 2
# print(a%b)  # 1
# print(a**b) # 25

# ---------------------------------------------

# a = int(input("Son kiriting: "))
# print(sum := a%10 + a//10)

# ---------------------------------------------
    #  kesish

matn = "salom dunyo"

# print(matn[-1]) # o
# matn[0] = "S" # ERROR

# [start:stop:step]
# matn[1:] # alom dunyo
# matn[4:9] # m dun
# matn[:5] # salom
# matn[:] # salom dunyo
# matn[1::2] # ao uy
# matn[::-1] # oynud molas

# matn = "S" + matn[1:]
# matn = matn[:6] + "D" + matn[7:]
# print(matn)

# ------------------------------------------------

# ful_name = input("Name: ") + "  " + input("Second: ")
# print(ful_name)


# natija = "salom" * 2
# print(natija)



# try: 
#     print("SALOM")
#     print(5/0)
# except:
#     print("BU YERDA HATOLIK BOR") 




#HOMEWORK 1
# def otgan_talabalar(grades: list[int], otishbahosi: int):
#     count =0


#     for baho in baholar:
#         if baho>= otishbahosi:
#             count+=1

#     return count



# baholar=list(map(int, input ("Balllari kiritin: ").split()))
# otishbahosi=int(input("MINIMAL OTISH BAHOSINI BELGILANG:"))
# natija= otgan_talabalar(baholar, otishbahosi)
# print (natija)


#HOMEWORK 2
# def gram(words: list[str]):
#     result=[]


#     for soz in sozlar:
#         if soz.lower()[-4:]=="gram":
#             result.append(soz)

#     return(result)


# sozlar=input("SOZLARNI KIRITING :").split()
# print(gram(sozlar))


#HOMEWORK 3
def sana_yozma(sana: str ):
    qismlar=sana.split('.')


    day=int(qismlar[0])
    month=(qismlar[1])
    year=int(qismlar[2])


    months = {
        "01": "Yanvar",
        "02": "Fevral",
        "03": "Mart",
        "04": "Aprel",
        "05": "May",
        "06": "Iyun",
        "07": "Iyul",
        "08": "Avgust",
        "09": "Sentabr",
        "10": "Oktabr",
        "11": "Noyabr",
        "12": "Dekabr"
    }

    oy_nomi=months[month]
    return f"{day} {oy_nomi} {year} yil"


date=input("SANANI KIRITINH:>>>")
print(sana_yozma(date))





