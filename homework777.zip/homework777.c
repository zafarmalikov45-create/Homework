#include <stdio.h>
int main( ){
// int x;
// printf("Sonni kiriting:" );
// scanf("%d", &x);

// if(x>0 && x<9){
//     puts(" BIR HONALI SON");
// } else if( x>9 && x<99){
//     puts(" IKKI XONALI SON");
// }else if(x>99 && x<999){
//     puts(" UCH XONALI SON" );
// }else if(x>999 && x<9999){
//     puts( " TORT XONALI SON");
//  }else if(x>9999 && x<99999){
//     puts( " BESH XONALI SON");
//  }else {
//     puts(" JUDA KATTA SON");
//  }



// char harf;
// printf(" Harfni kiriting:");
// scanf ("%c", &harf);

// if(harf>='a' && harf<='z'){
//     harf=harf - 32;
// }
// printf("%c", harf);


// int kun;
// printf(" Ish kunini kiriting:");
// scanf("%d", &kun);

// if (kun>0 && kun<=5){
//     puts("ISH KUNI ");
// }else if( kun>5 && kun<=7){
//     puts( "DAM OLISH KUNI");
// }else {
//     puts("BUNDAY KUN YOQ");
// }



// char belgi;
// printf(" Belgini kiriting:");
// scanf(" %c", &belgi);
// if (belgi=='a' || belgi=='A' || belgi=='e' ||belgi=='E' || belgi=='i' || belgi=='I' || belgi=='o' || belgi=='O' || belgi=='u' ||belgi=='U'){
//     puts("UNLI HARF");
// }else {
//         puts(" UNDOSH HARF");
//     }


int a, b, c;

    printf("Uchta butun son kiriting: ");
     scanf("%d %d %d", &a, &b, &c);


    if ((a > b && a < c) || (a > c && a < b)) {
        printf("%d", a);
    }
    else if ((b > a && b < c) || (b > c && b < a)) {
        printf("%d", b);
    }
    else {
        printf("%d", c);
    }




}




                
            
        
    
    
    




    




