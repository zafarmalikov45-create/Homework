#include <stdio.h>
#include <ctype.h>


int main(){
    // char a;
    // printf("BELGINI KIRITING:");
    // scanf(" %c", &a);


    // switch(a){
    //     case '*':
    //     puts("KOPAYTIRUV");
    //     break;

    //     case '/':
    //     puts(" BOLUV");
    //     break;

    //     case '+':
    //     puts("QOSHUV");
    //     break;

    //     case '-':
    //     puts (" AYIRUV");
    //     break;

    //     default:
    //     puts("BUNDAY AMAL YOQ");

    // }


    // char a;
    // printf(" BELGI KIRITING:");
    // scanf(" %c", &a);

    // switch(a){ 
    //  case 'A':
    //  puts (" ALO");
    //  break;

    //  case 'E':
    //  puts ("YAXSHI");
    //  break;

    //  case 'F':
    //  puts (" YOMON");
    //  break;


    //  default:
    //  puts(" NOTOGRI BAHO");
    // }


    // int son;
    // printf(" SONNINGIZNI KIRITING:");
    // scanf(" %d", &son);

    // switch (son > 10) {
    //     case 1:
    //         puts("Chegaradan oshdi.");
    //         break;
    //     case 0:
    //         puts("Me'yorda.");
    //         break;
    // }



      int baho;
      printf(" BAGOINGIZNI KIRITING:");
    scanf("%d", &baho);

    switch (baho >= 60) {
        case 1:
            puts("Imtihondan o'tdi.");
            break;
        case 0:
            puts("Imtihondan yiqildi.");
            break;

}

}
                
            
        
    
    
    




    




