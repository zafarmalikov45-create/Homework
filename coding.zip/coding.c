#include <stdio.h>
int main() {
    // int i= -10;
  

    // while(i<=10){
    //     printf("%d\n", i);
    //     i++;
    // }


    // int i=1, n;
    // printf("SONN KIRITING:");
    // scanf("%d", &n);


    // while(i<=n){
    //     printf("%d\n", i);
    //     i++;
    // }

    //  int  n;
    //  int sum=1;
    // printf("SONN KIRITING:");
    // scanf("%d", &n);

    // while(sum<n){
    //     printf("%d\n",  sum);
    //     sum+= 4;
       
    // }


    // int kitob, sum=0, i=1;

    // printf(" Nechta kitob oqigansiz:");
    // while(i<=7){
    //     scanf ("%d", &kitob);
    //     sum +=kitob;
    //     i++;
    // }

    // printf("JMAI OQILGAN KITOBLAR SONI: %d", sum);
    


    int son, sum=0;


    while(1){
        scanf("%d", &son);
        if (son==0){
            break;
        }

        if (son>0){
            sum += son;
        }
    }

    printf("%d", sum);


}


    

    










