# yil  = input ("TUGILGAN YILINGIZ KIRITING: ")
# oy = input ("TUGILGAN OYINGIZNI KIRITINH: ")
# print("BIRTHDAY is :" {yil} {oy})




# son= int (input("SONI  KIRITING:  "))
# print (sum := (son%10 + son//10%10 + son//100)**3)


# son1 = int (input(" IKI- XONALI SONNI KIRITING: "))
# print(sum := (son1%10 + son1//10)//2)


# ism =input ("ISMINGIZNI KIRITING:")
# second= input ("FAMILIYANGIZNI KIRITING: ")
# print(f"""
# FULL NAME: {ism} {second}""")


# son1 = int(input( " BIRINCHI SONNI KIRITING: "))
# son2 = int(input( " IKINCHI SONNI KIRITING: "))
# print(f"""
#       KOPAYTMA: {son1*son2}
#       BOLINMA {son1//son2}
#       YIGINDI: {son1+son2}
#       AYITMA: {son1 - son2}
#       """)


# soz = input ("BIRORTA SOZ KIRITING: ")
# son = int(ord(soz))
# print (son-96)


# soz= input ("SOZ KIRITING: ")
# uzunligi= len(soz)
# print (uzunligi**3)



# year = int(input ("TUGILGAN YILINGIZNI KIRITING: " ))
# print (2026- year)



# harf = input ("BITTA HARF KIRITING:")
# katta =harf+32
# print ()



# a, b = 96, 28
# print (c:=a+b)



# matn = "salom zafar nma gap"
# matn="S"+matn[1:]
# print (matn)


# matn= "BUGUN DARS BOLMAYDI"
# matn = matn[:6]+ "d"+ matn [7:]
# print (matn)

# fullname= input("ISMINGIZNI KIRITING: ")+ " " +  input ("FAMILIYANGIZNI KIRITING: ")
# print (fullname)


a_kun= int(input("A USERNI TUGILGAN KUNI: "))
a_oy= int (input("A USERNI TUGILGAN OYI: "))
a_yil= int (input("A USERNI TIGILGAN YILI:" ))



b_kun= int(input("B USERNI TUGILGAN KUNI: "))
b_oy= int (input("B USERNI TUGILGAN OYI: "))
b_yil= int (input("B USERNI TIGILGAN YILI: "))

a_kun, b_kun= b_kun, a_kun
a_yil, b_yil= b_yil, a_yil


print (f"a = {a_kun}--{a_oy}--{a_yil}")
print(f"b= {b_kun}-- {b_oy}--{b_yil} ")