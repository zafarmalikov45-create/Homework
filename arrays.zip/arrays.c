#include <stdio.h>

int main() {
    // int arr[7];
    // for(int i = 0; i < 7; i++) {
    //     scanf("%d", &arr[i]);
    // }

    // for(int i = 0; i < 7; i++) {
    //     printf("%d ", arr[i] * arr[i]);
    // }


   
    // int arr[6];
    // for (int i = 0; i < 6; i++) {
    //     scanf("%d", &arr[i]);
    // }

    // for (int i = 5; i >= 0; i--) {
    //     printf("%d ", arr[i]);
    // }


    // int arr[6];
    // for (int i = 0; i < 6; i++) {
    //     scanf("%d", &arr[i]);
    // }

    // for (int i = 0; i < 6; i++) {
    //     if (arr[i] < 0) {
    //         arr[i] = -arr[i];
    //     }
    // }

    // for (int i = 0; i < 6; i++) {
    //     printf("%d ", arr[i]);
    // }


//  int arr[5];
//  int x, count=0;


//  for (int i=0; i<5; i++){
//     scanf("%d", &arr[i]);
//  }


//  printf("Qaysi sonni aniqlamoqchisiz: ");
//  scanf("%d", &x);


//  for (int i =0; i<5; i++){
//     if (arr[i]==x){
//         count++;
//     }
//  }

//  printf("SIZ KIRITGAN SON %d - marta uchragan ", count);

// int max, min;
// int arr[8];
//  for (int i=0; i<8; i++){
//   scanf("%d", &arr[i]);
  
// max=arr[0];
// min=arr[0];

// for (int i=1; i<8; i++){
//     if(arr[i]>max){
//         max=arr[i];
//     }
//     else if (arr[i]<min){
//         min=arr[i];
//     }
// }

// }
// printf("%d - maksimum va minimum sonlarni farqi", max-min);


// int arr[6];
// int max = 0;
// for (int i = 0; i < 6; i++) {
// scanf("%d", &arr[i]);
// }

// for (int i = 0; i < 6; i++) {
//  if (arr[i] % 2 == 0) {
//  if (arr[i] > max) {
//  max = arr[i];
// }
//  }
// }

// printf("Eng katta juft son: %d", max);


int arr[7];
 int sum = 0;
int orta;


 for (int i = 0; i < 7; i++) {
 scanf("%d", &arr[i]);
 sum += arr[i];
}

orta= sum/7;

for (int i = 0; i < 7; i++) {
if (arr[i] > orta) {
 printf("%d ", arr[i]);
 }
}
}

