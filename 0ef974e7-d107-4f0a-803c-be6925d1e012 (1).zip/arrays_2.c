#include <stdio.h>
#include "lib.h"


void BubbleSort(int arr[], int n){
    int x, i, temp;

    for (x = 0; x < n - 1; x++){
        for (i = 0; i < n - 1 - x; i++){
            if (arr[i] > arr[i+1]){   
                temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
            }
        }
    }
}



int minimum(int arr[], int n){
    int min= arr[0];
    int count =0;


for (int x=0; x<n;x++){
    if (min>arr[x]){
        min=arr[x];
        count = x;
    }
}

return count;
}



void check (int arr[], int n){
    int i;
    int min=arr[0], max =arr[0];
    int min_index =0, max_index=0;



    for ( int x =1; x<n; x++){
        if ( arr[x]> max ){
            max=arr[x];
            max_index=x;

        }else if (arr[x]<min){
            min= arr[x];\
            min_index=x;
        }
    }


    if (max_index>min_index){
        printf("minnimal son max dan oldin kelayipti ");
    }else {
        printf("minimal son maksimumdan keyin kelayapti ");
    }
}


int main (){
//     int n;
//  printf("NECHTA SON KIRITASIZ: " );
//  scanf("%d", &n);

// int arr[n];
//  for (int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
//  }

//  int min= arr[0];

//  for (int f=1; f<n; f++){
//     if (min>arr[f]){
//         min=arr[f];
//     }
//  }


//  printf("%d- eng minimal son ", min);



// int n;
// printf("NECHTA SON KIRITASIZ : ");
// scanf("%d", &n);

// int arr[n];


// for (int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
//     if (arr[x]%2!=0){
//         arr[x]= arr[x]*2;
//     }else {
//         arr[x]=arr[x]+2;
//     }
// }


// for (int t=0; t<n; t++){
//     printf("%d ", arr[t]);
// }


// int n; 
// printf("NECHTA SON KIRITASIZ : ");
// scanf("%d", &n);

// int arr[n];

// for (int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
//     if (arr[x]>0){
//         arr[x]=1;
//     }else{ 
//         arr[x]=0;
//     }
// }

// for ( int t=0; t<n; t++){
//    printf("%d ", arr[t]) ;
// }


// int n;
// printf("NECHTA SON KIRITASIZ: ");
// scanf("%d", &n);


// int arr[n];


// for(int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
// }

// int son= arr[n-1];


// for (int t=n-1; t>0; t--){
//     arr[t]=arr[t-1];
// }

// arr[0]=son;


// for (int r=0; r<n; r++){
//     printf("%d ", arr[r]);
// }


// int n;
// printf("NECHTA SON KIRITASIZ: ");
// scanf("%d", &n);

// int arr[n];

// for (int x = 0; x < n; x++) {
// scanf("%d", &arr[x]);   

// int tekshiruv = 1;  

//  for (int i = 0; i < n; i++) {

//  if (i % 2 == 0 && arr[i] % 2 != 0) {   
//  tekshiruv = 0;
//  }
//  else if (i % 2 == 1 && arr[i] % 2 == 0) { 
//   tekshiruv = 0;
//  }

// }

// if (tekshiruv == 1) printf("true ");
// else printf("false ");
// }



// int n;
// printf("Nechta son kiritasiz :");
// scanf("%d", &n);

// int arr[n];


// for (int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
// }




// BubbleSort(arr,n);



// printf("%d- second max soni", arr[n-2]);


// int n;
// printf("NECHTA SON KIRITASIZ: ");
// scanf("%d", &n);

// int arr[n];


// for (int x=0; x<n; x++){
//     scanf("%d", &arr[x]);
// }


// int result = minimum(arr, n);

// printf("%d- minimums son oldin shuncha son bor ", result );


int n;
printf("NECHTA SON KIRITASIZ : ");
scanf("%d", &n);

int arr[n];

for (int x=0; x<n; x++){
    scanf("%d", &arr[x]);
}


check(arr, n);
}







