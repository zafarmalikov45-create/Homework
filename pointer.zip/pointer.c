#include <stdio.h>

int main (){
    // int son= 20;
    // int *ptr= &son;


    // printf("%d - qiymat\n ", son );
    // printf("%p- manzil  ",(void*) ptr);


    // int son=20;
    // int *ptr = &son;


    // printf("%d- qiymat", *ptr);



    // int son = 30;
    // int *ptr = &son;
    // *ptr=50;

    // printf("%d- yangi qimat ", son);



    // int son =100;
    // int *ptr= &son;
    // int *ptr2=&son ;

    // printf("%d-ptr1 qiymati\n", *ptr);
    // printf("%d-ptr2 qiymati", *ptr2);

    // int son=8;
    // int *ptr= &son;
    // *ptr= 2*son;

    // printf("YANGI QIMAT- %d", *ptr);

    
    // int a=10, b=12;
    // int *ptr1= &a;
    // int *ptr2= &b;
    
    // if (ptr1==ptr2){
    //     printf("MANZILAR BIR XIL");
    // }else {
    //     printf("MANZILLAR XAR HIL");
    // }


//     int *ptr= NULL;

//     if (ptr == NULL){
//         printf("POINTER TENG NULLGA");
        
// }else {
//     printf("pointer mazilga ega ");
// }


int son;
printf("SONNI KIRQIZING:");
scanf("%d", &son);


int *ptr= &son;

printf("%d - siz kiritgan son ", *ptr);
}








