#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
typedef struct kutubxona{
   char nomi[50];
   char muallif[50];
   float narx;

}kutubxona;

typedef struct ishchilar{
    char name[50];
    char lavozim[50];
    float maosh;
}ishchilar;

typedef struct kantakt{
    char ism[50];
    char  nomer[50];
}kontakt;

typedef struct xodimlar{
    char name[50];
    int maosh;
    int mukofat;
}xodimlar;


int main(){

//     kutubxona arr[5];

//    strcpy(arr[0].nomi, "Dunyo Tarixi ");
//    strcpy(arr[0].muallif, "Aliyev ");
//    arr[0].narx =  120000;

//    strcpy(arr[1].nomi, "Matematika ");
//    strcpy(arr[1].muallif, " Asqarov ");
//    arr[1].narx = 90000;

//    strcpy(arr[2].nomi, "Fizika ");
//    strcpy(arr[2].muallif, " Karimov ");
//    arr[2].narx = 110000;

//    strcpy(arr[3].nomi, "Adabiyot ");
//    strcpy(arr[3].muallif, " Rustamova ");
//    arr[3].narx = 80000;

//    strcpy(arr[4].nomi, "Kimyo ");
//    strcpy(arr[4].muallif, " Tursunov ");
//    arr[4].narx = 95000;

// // FILE *kxona=fopen("Library_books.txt","w");

// // fprintf(kxona,"%s %s %.1f\n", arr[0].nomi, arr[0].muallif, arr[0].narx);
// // fprintf(kxona,"%s %s %.1f\n", arr[1].nomi, arr[1].muallif, arr[1].narx);
// // fprintf(kxona,"%s %s %.1f\n", arr[2].nomi, arr[2].muallif, arr[2].narx);
// // fprintf(kxona,"%s %s %.1f\n", arr[3].nomi, arr[3].muallif, arr[3].narx);
// // fprintf(kxona,"%s %s %.1f\n", arr[4].nomi, arr[4].muallif, arr[4].narx);

// // fclose(kxona);

// FILE *kxona=fopen("Library_books.txt","r");
// FILE *chegirma=fopen("discounted_books.txt","w");


// fscanf(kxona,"%s %s %f", arr[0].nomi, arr[0].muallif, &arr[0].narx);
// arr[0].narx = arr[0].narx * 0.85;
// fprintf(chegirma,"%s %s %.1f\n", arr[0].nomi, arr[0].muallif, arr[0].narx);

// fscanf(kxona,"%s %s %f", arr[1].nomi, arr[1].muallif, &arr[1].narx);
// arr[1].narx = arr[1].narx * 0.85;
// fprintf(chegirma,"%s %s %.1f\n", arr[1].nomi, arr[1].muallif, arr[1].narx);

// fscanf(kxona,"%s %s %f", arr[2].nomi, arr[2].muallif, &arr[2].narx);
// arr[2].narx = arr[2].narx * 0.85;
// fprintf(chegirma,"%s %s %.1f\n", arr[2].nomi, arr[2].muallif, arr[2].narx);

// fscanf(kxona,"%s %s %f", arr[3].nomi, arr[3].muallif, &arr[3].narx);
// arr[3].narx = arr[3].narx * 0.85;
// fprintf(chegirma,"%s %s %.1f\n", arr[3].nomi, arr[3].muallif, arr[3].narx);

// fscanf(kxona,"%s %s %f", arr[4].nomi, arr[4].muallif, &arr[4].narx);
// arr[4].narx = arr[4].narx * 0.85;
// fprintf(chegirma,"%s %s %.1f\n", arr[4].nomi, arr[4].muallif, arr[4].narx);

// fclose(kxona);
// fclose(chegirma);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//     ishchilar arr[5];

//    strcpy(arr[0].name, "Anvar ");
//    strcpy(arr[0].lavozim, "Muhandis ");
//    arr[0].maosh =  5000000;
   
//    strcpy(arr[1].name, "Jasur ");
//    strcpy(arr[1].lavozim, "Dasturchi ");
//    arr[1].maosh =  8000000;
   
//    strcpy(arr[2].name, "Dilfuza ");
//    strcpy(arr[2].lavozim, "Dizayner ");
//    arr[2].maosh =  6000000;
   
//    strcpy(arr[3].name, "Madina ");
//    strcpy(arr[3].lavozim, "Hisobchi ");
//    arr[3].maosh =  5500000;
   
//    strcpy(arr[4].name, "Shohrux ");
//    strcpy(arr[4].lavozim, "Menedjer ");
//    arr[4].maosh =  700000;
   
// //    FILE *ishxona=fopen("employees.txt","a");

// // fprintf(ishxona,"%s %s %f\n", arr[0].name, arr[0].lavozim, arr[0].maosh);
// // fprintf(ishxona,"%s %s %f\n", arr[1].name, arr[1].lavozim, arr[1].maosh);
// // fprintf(ishxona,"%s %s %f\n", arr[2].name, arr[2].lavozim, arr[2].maosh);
// // fprintf(ishxona,"%s %s %f\n", arr[3].name, arr[3].lavozim, arr[3].maosh);
// // fprintf(ishxona,"%s %s %f\n", arr[4].name, arr[4].lavozim, arr[4].maosh);


// FILE *ishxona=fopen("employees.txt","r");

// FILE *ishxonaw=fopen("updated_employees.txt","w");

// fscanf(ishxona,"%s %s %f\n", arr[0].name, arr[0].lavozim, &arr[0].maosh);
// arr[0].maosh=arr[0].maosh * 1.05;
// fprintf(ishxonaw,"%s %s %f\n", arr[0].name, arr[0].lavozim, arr[0].maosh);
// fscanf(ishxona,"%s %s %f\n", arr[1].name, arr[1].lavozim, &arr[1].maosh);
// arr[1].maosh=arr[1].maosh * 1.05;
// fprintf(ishxonaw,"%s %s %f\n", arr[1].name, arr[1].lavozim, arr[1].maosh);
// fscanf(ishxona,"%s %s %f\n", arr[2].name, arr[2].lavozim, &arr[2].maosh);
// arr[2].maosh=arr[2].maosh * 1.05;
// fprintf(ishxonaw,"%s %s %f\n", arr[2].name, arr[2].lavozim, arr[2].maosh);
// fscanf(ishxona,"%s %s %f\n", arr[3].name, arr[3].lavozim, &arr[3].maosh);
// arr[3].maosh=arr[3].maosh * 1.05;
// fprintf(ishxonaw,"%s %s %f\n", arr[3].name, arr[3].lavozim, arr[3].maosh);
// fscanf(ishxona,"%s %s %f\n", arr[4].name, arr[4].lavozim, &arr[4].maosh);
// arr[4].maosh=arr[4].maosh * 1.05;
// fprintf(ishxonaw,"%s %s %f\n", arr[4].name, arr[4].lavozim, arr[4].maosh);


// fclose(ishxona);
// fclose(ishxonaw);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// FILE *f = fopen("input.txt","w");

//     fprintf(f,"Bugun ob-havo juda yaxshi. Quyosh charaqlab turibdi.\n");
//     fprintf(f,"Daraxtlar yashillikka burkangan, Qushlar chirqilaydi. \n");
//     fprintf(f,"Ko'chada odamlar xursand yurishmoqda.");

// fclose(f);

//    FILE *f = fopen("input.txt", "r");

//     char soz[100];
//     int count = 0;

//     while (fscanf(f, "%s", soz) != EOF) {
//         count++;
//     }

//     printf("Umumiy sozlar soni: %d\n", count);

//     fclose(f);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//FILE *log = fopen("log.txt","a");

// fprintf(log,"2025-03-06 12:00:34 - Fayl ochildi\n");
// fprintf(log,"2025-03-06 12:00:36 - Ma'lumot o'qildi\n");
// fprintf(log,"2025-03-06 12:00:38 - Xatolik yuz berdi\n");

//     fclose(log);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// kontakt arr[5];

// strcpy(arr[0].ism, "Jasur ");
// strcpy(arr[0].nomer,"+998901234567");
// strcpy(arr[1].ism, "Dilfuza ");
// strcpy(arr[1].nomer, "+998909876543");
// strcpy(arr[2].ism, "Madina ");
// strcpy(arr[2].nomer,"+998931112233");
// strcpy(arr[3].ism, "Anvar ");
// strcpy(arr[3].nomer,"+998907654321");
// strcpy(arr[4].ism, "Shohrux ");
// strcpy(arr[4].nomer,"+998933343207");

// FILE *k=fopen("contacts.txt","w");
// for(int i=0; i<5; i++){
//     fprintf(k,"%s %s \n",arr[i].ism,  arr[i].nomer );
// }

// fclose(k);

// char name[50];
// puts("->Kimno nomerini qidiryapsiz...");
// printf("-Ism: ");
// scanf("%s",name);
// FILE *k=fopen("contacts.txt","r");
// for(int i=0; i<5; i++){
// while(fscanf(k,"%s %s", arr[i].ism, arr[i].nomer) != EOF){

//     if(strcmp(arr[i].ism, name)==0){
//         printf("%s %s\n", arr[i].ism, arr[i].nomer);
//     }

// }
// }

// fclose(k);

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// xodimlar arr[5];
 
// strcpy(arr[0].name, "Shohrux ");
// arr[0].maosh=3500000;
// arr[0].mukofat=2000000;

// strcpy(arr[1].name, "Madina ");
// arr[1].maosh=4500000;
// arr[1].mukofat=2500000;

// strcpy(arr[2].name, "Dilfuza ");
// arr[2].maosh=5000000;
// arr[2].mukofat=3000000;

// strcpy(arr[3].name, "Anvar ");
// arr[3].maosh=3200000;
// arr[3].mukofat=1800000;

// strcpy(arr[4].name, "Jasur ");
// arr[4].maosh=6000000;
// arr[4].mukofat=3500000;

// FILE *H=fopen("report.txt","a");
// for(int i=0; i<5; i++){
//     fprintf(H,"%s %d %d \n",arr[i].name, arr[i].maosh, arr[i].mukofat);
// }
// fclose(H);

//  

// FILE *H=fopen("report.txt","r");
// for(int i=0; i<5; i++){
//     fscanf(H,"%s %d %d \n",arr[i].name, &arr[i].maosh, &arr[i].mukofat);
//     int natija= arr[i].maosh + arr[i].mukofat;
//     printf("%s  %d \n",arr[i].name, natija);
// }

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

char matn[100];
puts("Matn kiriting...");    
printf("-");
scanf("%[^\n]", matn);
for(int i=0; i<matn[i]; i++){
    int count=0;
    for(int x=0; x<matn[x]; x++){
        if(matn[i]==matn[x]){
            count++;
        }
    }
    if(count>2){
      printf("%c - %d marta:\n",matn[i],count-1);
    }
}



}