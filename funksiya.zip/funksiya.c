#include <stdio.h>
#include "lib.h"
#include <ctype.h>

int main(){
  // char harf;
  // printf("HARFNI KIRITING: ");
  // scanf(" %c", &harf);


  // bukva(harf);


// int a, b;
// printf("IKKTA SONNI KIRITING: ");
// scanf("%d%d", &a, &b);


// daraja(a, b);



// float a, b, c;
// printf("UCHTA SONNI KIRITING: ");
// scanf("%f%f%f", &a, &b, &c);


// high(a, b, c);



// int a; 
// printf("BITTA BUTUN SON KIRITING: ");
// scanf("%d", &a);

// butun(a);


int son;
printf("BITTA BUTUN SON KIRITING: ");
scanf("%d", &son);



chiqar(son);
}