 #include <stdio.h>

int main() {
    int son;

    while (1) {
        printf("SONNI KIRITING : ");
        scanf("%d", &son);

        if (son == 0) {
            break;
        }

        switch (son) {
            case 1: 
            printf("BIR\n");
             break;
            case 2:
             printf("IKKI\n");
              break;
            case 3:
             printf("UCH\n");
              break;
            case 4:
             printf("TORT\n");
              break;
            case 5:
             printf("BESH\n");
              break;
            case 6:
             printf("OLTI\n");
              break;
            case 7: 
            printf("YETTI\n");
             break;
            case 8:
             printf("SAKKIZ\n");
              break;
            case 9:
             printf("TOQQIZ\n"); 
             break;
            default: printf("Janob 1 dan 9 gacha son kiriting\n");
        }
    }

   
    
}
   
   
    
